import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash } from "@fortawesome/free-solid-svg-icons";

import { userActions } from '../_actions';

class HomePage extends React.Component {
    componentDidMount() {
        this.props.getUsers();
    }

    handleDeleteUser(id) {
        return (e) => this.props.deleteUser(id);
    }

    render() {
        const { user, users } = this.props;
        return (
            <div className="col-md-12">
                <h2>Welcome to React Dashboard {user.firstName}!</h2>
                <h3 className="mt-10">All registered users:</h3>
                {users.loading && <em>Loading users...</em>}
                {users.error && <span className="text-danger">ERROR: {users.error}</span>}
                {users.items &&
                    <ul className="list-group">
                        {users.items.map((user, index) =>
                            <li key={user.id} className={'list-group-item list-group-item-dark' + (user.id % 2 === 0 ? ' list-group-item-light' : 'list-group-item-dark')}>
                            <div className="row">
                                <div className="col-md-3">{user.firstName}</div>
                                <div className="col-md-3">{user.lastName}</div>
                                <div className="col-md-4">{user.email}</div>
                                <div className="col-md-2">
                                {
                                    user.deleting ? <em> - Deleting...</em>
                                    : user.deleteError ? <span className="text-danger"> - ERROR: {user.deleteError}</span>
                                    : <a onClick={this.handleDeleteUser(user.id)} style={{color: 'red'}}><FontAwesomeIcon icon={faTrash} /></a>
                                }
                                </div>
                            </div>
                            </li>
                        )}
                    </ul>
                }
                <p className="mt-3">
                    <Link to="/login">Logout</Link>
                </p>
            </div>
        );
    }
}

function mapState(state) {
    const { users, authentication } = state;
    const { user } = authentication;
    return { user, users };
}

const actionCreators = {
    getUsers: userActions.getAll,
    deleteUser: userActions.delete
}

const connectedHomePage = connect(mapState, actionCreators)(HomePage);
export { connectedHomePage as HomePage };