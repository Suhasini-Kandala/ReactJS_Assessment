import renderer from 'react-test-renderer';

describe('<LoginPage>', () => {
  test('Should render correctly', () => {
    // We can write test scripts to check component rendering
  });
});
