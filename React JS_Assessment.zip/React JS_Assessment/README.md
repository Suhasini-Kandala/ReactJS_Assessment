# React Dashboard Example

Project run guidelines

In Command Project open the package json folder and run 

"npm install" command to load node modules

"npm start" - To Start the project

"npm test" - To run test scripts

"npm run lint" - To check for coding guidelines

