module.exports = {
	testRegex: '/src/.*?(Spec)\\.js$',
	modulePathIgnorePatterns: ['node_modules'],
	"modulePaths": [
  		"<rootDir>"
	]
}